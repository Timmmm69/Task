﻿[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [string]$EvidenceDirectory,
    [switch]$SkipBuild,
    [switch]$LocationsOnly
)

if ($PSVersionTable.PSEdition -ne 'Core') {
    $pwsh = Get-Command pwsh.exe -ErrorAction Stop
    $forward = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', $PSCommandPath,
        '-EvidenceDirectory', $EvidenceDirectory)
    if ($SkipBuild) { $forward += '-SkipBuild' }
    if ($LocationsOnly) { $forward += '-LocationsOnly' }
    & $pwsh.Source @forward
    exit $LASTEXITCODE
}

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$repoRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..\..'))
$outputRoot = [IO.Path]::GetFullPath((Join-Path $repoRoot 'outputs'))
$evidenceRoot = [IO.Path]::GetFullPath($EvidenceDirectory)
$outputPrefix = $outputRoot.TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
if (-not $evidenceRoot.StartsWith($outputPrefix, [StringComparison]::OrdinalIgnoreCase)) {
    throw 'EvidenceDirectory must be inside the repository outputs directory.'
}

$runtimeRoot = [IO.Path]::GetFullPath((Join-Path $env:LOCALAPPDATA 'TaskE2ERuntime\task-write-e2e'))
if ($LocationsOnly) { $runtimeRoot = [IO.Path]::GetFullPath((Join-Path $env:LOCALAPPDATA 'TaskE2ERuntime\task-locations-e2e')) }
$isolatedDesktopData = Join-Path $runtimeRoot 'desktop-appdata'
$expectedRuntime = [IO.Path]::GetFullPath((Join-Path $env:LOCALAPPDATA 'TaskE2ERuntime\task-write-e2e'))
if ($LocationsOnly) { $expectedRuntime = [IO.Path]::GetFullPath((Join-Path $env:LOCALAPPDATA 'TaskE2ERuntime\task-locations-e2e')) }
if ($runtimeRoot -ne $expectedRuntime) { throw 'Unexpected QA-03 runtime path.' }
$writeE2E = Join-Path $PSScriptRoot 'Test-TaskWriteE2E.ps1'
$qa03Phases = Join-Path $PSScriptRoot 'Test-Qa03CriticalE2E.ps1'
$desktopExe = Join-Path $repoRoot 'work\production\src\Task.Desktop\bin\Release\net10.0-windows\Task.Desktop.exe'
$statePath = Join-Path $runtimeRoot 'state.json'
$runLog = Join-Path $evidenceRoot 'qa03-gate.log'
$buildLog = Join-Path $evidenceRoot 'qa03-release-build.log'
$pgBin = 'C:\Program Files\PostgreSQL\16\bin'
$desktopProcess = $null
$window = $null
$setupStarted = $false
$startedAt = [DateTimeOffset]::UtcNow

[IO.Directory]::CreateDirectory($evidenceRoot) | Out-Null
[IO.File]::WriteAllText($runLog, '', [Text.UTF8Encoding]::new($false))

function Write-Pass([string]$message) { Write-Host "[PASS] $message" }
function Assert-Qa03([bool]$condition, [string]$message) {
    if (-not $condition) { throw "QA-03 assertion failed: $message" }
    Write-Pass $message
}
function Append-Log([object[]]$content, [string]$path) {
    $text = ($content | ForEach-Object { $_.ToString() }) -join [Environment]::NewLine
    [IO.File]::AppendAllText($path, $text + [Environment]::NewLine, [Text.UTF8Encoding]::new($false))
}
function Invoke-Phase([string]$phase, [string[]]$extra = @()) {
    $heading = "=== Test-TaskWriteE2E phase: $phase ==="
    Append-Log @($heading) $runLog
    $arguments = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', $writeE2E,
        '-Phase', $phase, '-DesktopAppDataPath', $isolatedDesktopData) + $extra
    if ($LocationsOnly) { $arguments += @('-RuntimePath', $runtimeRoot) }
    $phaseStem = $phase.ToLowerInvariant()
    $stdoutPath = Join-Path $evidenceRoot "phase-$phaseStem.stdout.log"
    $stderrPath = Join-Path $evidenceRoot "phase-$phaseStem.stderr.log"
    $process = Start-Process -FilePath (Get-Command pwsh.exe).Source -ArgumentList $arguments `
        -WindowStyle Hidden -RedirectStandardOutput $stdoutPath -RedirectStandardError $stderrPath -PassThru
    $process.WaitForExit()
    $exitCode = $process.ExitCode
    $output = @()
    if (Test-Path -LiteralPath $stdoutPath) { $output += Get-Content -LiteralPath $stdoutPath }
    if (Test-Path -LiteralPath $stderrPath) { $output += Get-Content -LiteralPath $stderrPath }
    $process.Dispose()
    $output | ForEach-Object { Write-Host $_ }
    Append-Log $output $runLog
    if ($exitCode -ne 0) { throw "Test-TaskWriteE2E phase '$phase' failed with exit code $exitCode." }
}
function Invoke-Qa03Phase([string]$phase) {
    $heading = "=== Test-Qa03CriticalE2E phase: $phase ==="
    Append-Log @($heading) $runLog
    $arguments = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', $qa03Phases,
        '-Phase', $phase, '-EvidencePath', $evidenceRoot)
    $phaseStem = $phase.ToLowerInvariant()
    $stdoutPath = Join-Path $evidenceRoot "qa03-$phaseStem.stdout.log"
    $stderrPath = Join-Path $evidenceRoot "qa03-$phaseStem.stderr.log"
    $process = Start-Process -FilePath (Get-Command pwsh.exe).Source -ArgumentList $arguments `
        -WindowStyle Hidden -RedirectStandardOutput $stdoutPath -RedirectStandardError $stderrPath -PassThru
    $process.WaitForExit()
    $exitCode = $process.ExitCode
    $output = @()
    if (Test-Path -LiteralPath $stdoutPath) { $output += Get-Content -LiteralPath $stdoutPath }
    if (Test-Path -LiteralPath $stderrPath) { $output += Get-Content -LiteralPath $stderrPath }
    $process.Dispose()
    $output | ForEach-Object { Write-Host $_ }
    Append-Log $output $runLog
    if ($exitCode -ne 0) { throw "Test-Qa03CriticalE2E phase '$phase' failed with exit code $exitCode." }
}
function Stop-Desktop {
    if ($null -eq $script:desktopProcess) { return }
    $process = Get-Process -Id $script:desktopProcess.Id -ErrorAction SilentlyContinue
    if ($process) {
        $process.CloseMainWindow() | Out-Null
        if (-not $process.WaitForExit(10000)) {
            Stop-Process -Id $process.Id -Force
            $process.WaitForExit(5000) | Out-Null
        }
    }
    $script:desktopProcess = $null
}
function Invoke-Sql([string]$sql) {
    $state = Get-Content -LiteralPath $statePath -Raw | ConvertFrom-Json
    $result = & (Join-Path $pgBin 'psql.exe') -X -v ON_ERROR_STOP=1 -h 127.0.0.1 `
        -p $state.PostgresPort -U postgres -d $state.DatabaseName -tA -c $sql 2>&1
    if ($LASTEXITCODE -ne 0) { throw "PostgreSQL command failed: $($result -join [Environment]::NewLine)" }
    return ($result -join [Environment]::NewLine).Trim()
}

Add-Type -AssemblyName UIAutomationClient
Add-Type -AssemblyName UIAutomationTypes

function Find-ElementById([System.Windows.Automation.AutomationElement]$root, [string]$automationId) {
    $condition = [System.Windows.Automation.PropertyCondition]::new(
        [System.Windows.Automation.AutomationElement]::AutomationIdProperty, $automationId)
    return $root.FindFirst([System.Windows.Automation.TreeScope]::Descendants, $condition)
}
function Wait-ElementById([System.Windows.Automation.AutomationElement]$root, [string]$automationId,
    [int]$timeoutSeconds = 45, [switch]$Enabled) {
    $deadline = [DateTime]::UtcNow.AddSeconds($timeoutSeconds)
    do {
        $element = Find-ElementById $root $automationId
        if ($null -ne $element -and (-not $Enabled -or $element.Current.IsEnabled)) { return $element }
        Start-Sleep -Milliseconds 200
    } while ([DateTime]::UtcNow -lt $deadline)
    throw "UI Automation element '$automationId' was not ready within $timeoutSeconds seconds."
}
function Wait-ElementGoneById([System.Windows.Automation.AutomationElement]$root, [string]$automationId,
    [int]$timeoutSeconds = 45) {
    $deadline = [DateTime]::UtcNow.AddSeconds($timeoutSeconds)
    do {
        $element = Find-ElementById $root $automationId
        if ($null -eq $element -or $element.Current.IsOffscreen) { return }
        Start-Sleep -Milliseconds 200
    } while ([DateTime]::UtcNow -lt $deadline)
    throw "UI Automation element '$automationId' remained visible for $timeoutSeconds seconds."
}
function Find-ElementsByNameContains([System.Windows.Automation.AutomationElement]$root,
    [string]$text, [string]$controlType = '') {
    $condition = [System.Windows.Automation.Condition]::TrueCondition
    if ($controlType) {
        $condition = [System.Windows.Automation.PropertyCondition]::new(
            [System.Windows.Automation.AutomationElement]::ControlTypeProperty,
            [System.Windows.Automation.ControlType]::$controlType)
    }
    $matches = [Collections.Generic.List[System.Windows.Automation.AutomationElement]]::new()
    foreach ($element in $root.FindAll([System.Windows.Automation.TreeScope]::Descendants, $condition)) {
        try {
            if ($element.Current.Name.Contains($text, [StringComparison]::Ordinal)) { $matches.Add($element) }
        }
        catch { }
    }
    return ,@($matches)
}
function Wait-ElementByNameContains([System.Windows.Automation.AutomationElement]$root,
    [string]$text, [int]$timeoutSeconds = 60, [string]$controlType = '') {
    $deadline = [DateTime]::UtcNow.AddSeconds($timeoutSeconds)
    do {
        $found = Find-ElementsByNameContains $root $text $controlType
        if ($found.Count -ge 1) { return $found[0] }
        Start-Sleep -Milliseconds 250
    } while ([DateTime]::UtcNow -lt $deadline)
    throw "UI Automation element containing '$text' did not appear within $timeoutSeconds seconds."
}
function Wait-StatusText([System.Windows.Automation.AutomationElement]$window,
    [string]$fragment, [int]$timeoutSeconds = 45) {
    $deadline = [DateTime]::UtcNow.AddSeconds($timeoutSeconds)
    do {
        $status = Find-ElementById $window 'ConnectionStatusText'
        if ($null -ne $status -and $status.Current.Name.Contains($fragment)) { return $status }
        Start-Sleep -Milliseconds 250
    } while ([DateTime]::UtcNow -lt $deadline)
    throw "Connection status '$fragment' did not appear within $timeoutSeconds seconds."
}
function Wait-ElementByNameExact([System.Windows.Automation.AutomationElement]$root,
    [string]$name, [int]$timeoutSeconds = 30) {
    $condition = [System.Windows.Automation.PropertyCondition]::new(
        [System.Windows.Automation.AutomationElement]::NameProperty, $name)
    $deadline = [DateTime]::UtcNow.AddSeconds($timeoutSeconds)
    do {
        $element = $root.FindFirst([System.Windows.Automation.TreeScope]::Descendants, $condition)
        if ($null -ne $element) { return $element }
        Start-Sleep -Milliseconds 250
    } while ([DateTime]::UtcNow -lt $deadline)
    throw "UI Automation element named '$name' did not appear within $timeoutSeconds seconds."
}
function Dump-UiaTree([System.Windows.Automation.AutomationElement]$root, [string]$path) {
    $lines = [Collections.Generic.List[string]]::new()
    function Walk($element, [int]$depth) {
        if ($depth -gt 12 -or $null -eq $element) { return }
        $id = ''
        $name = ''
        try { $id = $element.Current.AutomationId; $name = $element.Current.Name } catch { }
        $type = $element.Current.ControlType.ProgrammaticName
        if ($id -or $name) { $lines.Add(('  ' * $depth) + "[$type] id='$id' name='$name'") }
        $children = $element.FindAll([System.Windows.Automation.TreeScope]::Children,
            [System.Windows.Automation.Condition]::TrueCondition)
        foreach ($child in $children) { Walk $child ($depth + 1) }
    }
    Walk $root 0
    [IO.File]::WriteAllLines($path, $lines, [Text.UTF8Encoding]::new($false))
}
function Invoke-Element([System.Windows.Automation.AutomationElement]$element) {
    $pattern = [System.Windows.Automation.InvokePattern]$element.GetCurrentPattern(
        [System.Windows.Automation.InvokePattern]::Pattern)
    $pattern.Invoke()
}
function Set-ElementValue([System.Windows.Automation.AutomationElement]$element, [string]$value) {
    $pattern = [System.Windows.Automation.ValuePattern]$element.GetCurrentPattern(
        [System.Windows.Automation.ValuePattern]::Pattern)
    $pattern.SetValue($value)
}
function Navigate-To([System.Windows.Automation.AutomationElement]$window, [string]$route, [string]$sectionId) {
    $deadline = [DateTime]::UtcNow.AddSeconds(30)
    do {
        $item = Wait-ElementById $window "Navigation_$route" 15
        $selection = [System.Windows.Automation.SelectionItemPattern]$item.GetCurrentPattern(
            [System.Windows.Automation.SelectionItemPattern]::Pattern)
        $selection.Select()
        $verifyDeadline = [DateTime]::UtcNow.AddSeconds(5)
        do {
            $section = Find-ElementById $window $sectionId
            if ($null -ne $section) { Start-Sleep -Milliseconds 400; return }
            Start-Sleep -Milliseconds 250
        } while ([DateTime]::UtcNow -lt $verifyDeadline)
        Write-Host "[WARN] Navigation to '$route' did not reveal '$sectionId'; reselecting."
    } while ([DateTime]::UtcNow -lt $deadline)
    Capture-Window 'navigation-failed' $window
    throw "Navigation to '$route' did not reveal '$sectionId'."
}
function Resize-Window(
    [System.Windows.Automation.AutomationElement]$window,
    [double]$width,
    [double]$height
) {
    $transform = [System.Windows.Automation.TransformPattern]$window.GetCurrentPattern(
        [System.Windows.Automation.TransformPattern]::Pattern)
    Assert-Qa03 $transform.Current.CanResize 'Main WPF window supports deterministic visual-QA sizing.'
    $transform.Resize($width, $height)
    Start-Sleep -Milliseconds 500
}
function Capture-Window(
    [string]$name,
    [System.Windows.Automation.AutomationElement]$window
) {
    Add-Type -AssemblyName System.Drawing
    Add-Type @'
using System;
using System.Runtime.InteropServices;
public static class Qa03WindowCapture {
    [StructLayout(LayoutKind.Sequential)] public struct RECT { public int Left, Top, Right, Bottom; }
    [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr hwnd, out RECT rect);
    [DllImport("user32.dll")] public static extern uint GetDpiForWindow(IntPtr hwnd);
    [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
    [DllImport("user32.dll")] public static extern bool PrintWindow(IntPtr hwnd, IntPtr hdcBlt, uint flags);
    [DllImport("user32.dll", SetLastError = true)] public static extern bool SetWindowPos(
        IntPtr hwnd, IntPtr insertAfter, int x, int y, int width, int height, uint flags);
}
'@
    [Qa03WindowCapture]::SetProcessDPIAware() | Out-Null
    $handle = [IntPtr]$window.Current.NativeWindowHandle
    Assert-Qa03 ($handle -ne [IntPtr]::Zero) 'Target WPF window handle is available.'
    $rect = [Qa03WindowCapture+RECT]::new()
    Assert-Qa03 ([Qa03WindowCapture]::GetWindowRect($handle, [ref]$rect)) 'Target window bounds are available.'
    $width = $rect.Right - $rect.Left; $height = $rect.Bottom - $rect.Top
    $positionOnly = 0x0004 -bor 0x0010
    Assert-Qa03 ([Qa03WindowCapture]::SetWindowPos($handle, [IntPtr]::Zero, 0, 0, $width, $height, $positionOnly)) 'Foreground window is positioned for complete capture.'
    Start-Sleep -Milliseconds 150
    Assert-Qa03 ([Qa03WindowCapture]::GetWindowRect($handle, [ref]$rect)) 'Capture window bounds are refreshed.'
    $width = $rect.Right - $rect.Left; $height = $rect.Bottom - $rect.Top
    $bitmap = [Drawing.Bitmap]::new($width, $height)
    try {
        $graphics = [Drawing.Graphics]::FromImage($bitmap)
        try {
            $deviceContext = $graphics.GetHdc()
            try {
                Assert-Qa03 ([Qa03WindowCapture]::PrintWindow($handle, $deviceContext, 2)) 'Target WPF window rendered to the evidence bitmap.'
            }
            finally { $graphics.ReleaseHdc($deviceContext) }
        }
        finally { $graphics.Dispose() }
        $path = Join-Path $evidenceRoot ($name + '.png')
        $bitmap.Save($path, [Drawing.Imaging.ImageFormat]::Png)
    }
    finally { $bitmap.Dispose() }
    Write-Pass "Captured $name.png."
}
function Start-Desktop {
    Assert-Qa03 (Test-Path -LiteralPath $desktopExe -PathType Leaf) 'Release WPF executable exists.'
    $previousDataDirectory = [Environment]::GetEnvironmentVariable('TASK_DESKTOP_DATA_DIRECTORY', 'Process')
    try {
        [Environment]::SetEnvironmentVariable('TASK_DESKTOP_DATA_DIRECTORY', $isolatedDesktopData, 'Process')
        $script:desktopProcess = Start-Process -FilePath $desktopExe -WorkingDirectory (Split-Path $desktopExe) -PassThru `
            -RedirectStandardOutput (Join-Path $evidenceRoot 'desktop.stdout.log') `
            -RedirectStandardError (Join-Path $evidenceRoot 'desktop.stderr.log')
    }
    finally {
        [Environment]::SetEnvironmentVariable('TASK_DESKTOP_DATA_DIRECTORY', $previousDataDirectory, 'Process')
    }
    $desktop = [System.Windows.Automation.AutomationElement]::RootElement
    $processCondition = [System.Windows.Automation.PropertyCondition]::new(
        [System.Windows.Automation.AutomationElement]::ProcessIdProperty, $script:desktopProcess.Id)
    $windowCondition = [System.Windows.Automation.PropertyCondition]::new(
        [System.Windows.Automation.AutomationElement]::AutomationIdProperty, 'MainWindow')
    $condition = [System.Windows.Automation.AndCondition]::new($processCondition, $windowCondition)
    $deadline = [DateTime]::UtcNow.AddSeconds(45)
    do {
        $window = $desktop.FindFirst([System.Windows.Automation.TreeScope]::Children, $condition)
        if ($null -ne $window) { break }
        if ($script:desktopProcess.HasExited) { throw 'Task.Desktop exited before opening MainWindow.' }
        Start-Sleep -Milliseconds 250
    } while ([DateTime]::UtcNow -lt $deadline)
    if ($null -eq $window) {
        $windows = $desktop.FindAll([System.Windows.Automation.TreeScope]::Children, $processCondition)
        $diagnostics = @(
            "ProcessId=$($script:desktopProcess.Id)",
            "HasExited=$($script:desktopProcess.HasExited)",
            "TopLevelWindows=$($windows.Count)"
        )
        foreach ($candidate in $windows) {
            $diagnostics += "Title=$($candidate.Current.Name); AutomationId=$($candidate.Current.AutomationId); Class=$($candidate.Current.ClassName); Enabled=$($candidate.Current.IsEnabled)"
            $descendants = $candidate.FindAll(
                [System.Windows.Automation.TreeScope]::Descendants,
                [System.Windows.Automation.Condition]::TrueCondition)
            foreach ($descendant in $descendants) {
                if (-not [string]::IsNullOrWhiteSpace($descendant.Current.Name)) {
                    $diagnostics += "  Name=$($descendant.Current.Name); AutomationId=$($descendant.Current.AutomationId); ControlType=$($descendant.Current.ControlType.ProgrammaticName)"
                }
            }
        }
        [IO.File]::WriteAllLines(
            (Join-Path $evidenceRoot 'desktop-timeout-windows.txt'),
            $diagnostics,
            [Text.UTF8Encoding]::new($false))
        throw 'Authenticated Task MainWindow did not open within 45 seconds. See desktop-timeout-windows.txt.'
    }
    return $window
}
function Find-MainWindow {
    $desktop = [System.Windows.Automation.AutomationElement]::RootElement
    $processCondition = [System.Windows.Automation.PropertyCondition]::new(
        [System.Windows.Automation.AutomationElement]::ProcessIdProperty, $script:desktopProcess.Id)
    $windowCondition = [System.Windows.Automation.PropertyCondition]::new(
        [System.Windows.Automation.AutomationElement]::AutomationIdProperty, 'MainWindow')
    $condition = [System.Windows.Automation.AndCondition]::new($processCondition, $windowCondition)
    return $desktop.FindFirst([System.Windows.Automation.TreeScope]::Children, $condition)
}
function Assert-TaskListItem([System.Windows.Automation.AutomationElement]$window,
    [string]$title, [int]$timeoutSeconds = 45) {
    $list = Wait-ElementById $window 'TasksList' $timeoutSeconds
    $condition = [System.Windows.Automation.PropertyCondition]::new(
        [System.Windows.Automation.AutomationElement]::ControlTypeProperty,
        [System.Windows.Automation.ControlType]::ListItem)
    $deadline = [DateTime]::UtcNow.AddSeconds($timeoutSeconds)
    do {
        $items = $list.FindAll([System.Windows.Automation.TreeScope]::Descendants, $condition)
        foreach ($item in $items) {
            if ($item.Current.Name.StartsWith($title + '.', [StringComparison]::Ordinal)) { return $item }
        }
        Start-Sleep -Milliseconds 250
    } while ([DateTime]::UtcNow -lt $deadline)
    throw "Task '$title' did not appear in the WPF task list."
}
function Assert-ListContains([System.Windows.Automation.AutomationElement]$window,
    [string]$listId, [string]$fragment, [int]$timeoutSeconds = 60) {
    $list = Wait-ElementById $window $listId $timeoutSeconds
    $deadline = [DateTime]::UtcNow.AddSeconds($timeoutSeconds)
    do {
        $elements = $list.FindAll([System.Windows.Automation.TreeScope]::Descendants,
            [System.Windows.Automation.Condition]::TrueCondition)
        foreach ($element in $elements) {
            try {
                if ($element.Current.Name.Contains($fragment, [StringComparison]::Ordinal)) { return $element }
            }
            catch { }
        }
        Start-Sleep -Milliseconds 250
    } while ([DateTime]::UtcNow -lt $deadline)
    throw "List '$listId' did not show an item containing '$fragment' within $timeoutSeconds seconds."
}
function Login-Api([string]$login) {
    $state = Get-Content -LiteralPath $statePath -Raw | ConvertFrom-Json
    $body = @{ login = $login; password = $state.AccountPassword; device = @{
        deviceKey = [guid]::NewGuid().ToString('N'); deviceName = 'QA-03 gate conflict'
        platform = 'windows'; appVersion = '1.0.0'; osVersion = 'Windows E2E'
    } } | ConvertTo-Json -Depth 4 -Compress
    $response = Invoke-WebRequest -Method Post -Uri "$($state.BaseUrl)/api/v1/auth/login" `
        -ContentType 'application/json' -Body $body -SkipHttpErrorCheck
    if ($response.StatusCode -ne 200) { throw 'Gate API login failed.' }
    return $response.Content | ConvertFrom-Json
}
function Patch-TaskTitle([string]$taskId, [string]$title) {
    $state = Get-Content -LiteralPath $statePath -Raw | ConvertFrom-Json
    $tokens = Login-Api $state.AdminLogin
    $headers = @{ Authorization = "Bearer $($tokens.accessToken)"; 'X-Correlation-ID' = [guid]::NewGuid().ToString('D') }
    $current = Invoke-WebRequest -Uri "$($state.BaseUrl)/api/v1/tasks/$taskId" -Headers $headers -SkipHttpErrorCheck
    if ($current.StatusCode -ne 200) { throw 'Gate task read failed.' }
    $etag = ($current.Headers['ETag'] | Select-Object -First 1).ToString()
    $headers['If-Match'] = $etag
    $headers['Idempotency-Key'] = [guid]::NewGuid().ToString('N')
    $body = @{ title = $title } | ConvertTo-Json -Compress
    $patch = Invoke-WebRequest -Method Patch -Uri "$($state.BaseUrl)/api/v1/tasks/$taskId" `
        -Headers $headers -ContentType 'application/json' -Body $body -SkipHttpErrorCheck
    if ($patch.StatusCode -ne 200) { throw 'Gate task conflict mutation failed.' }
}

function Test-LocationManager([System.Windows.Automation.AutomationElement]$window) {
    Navigate-To $window 'catalog' 'WorkHubView'
    $name = 'QA-03 location manager UI file'
    Set-ElementValue (Wait-ElementByNameExact $window 'Название записи' 30) $name
    Invoke-Element (Wait-ElementById $window 'CreateCatalogItemButton' 30 -Enabled)
    Assert-ListContains $window 'CatalogList' $name 60 | Out-Null
    Wait-ElementById $window 'LocationsEmpty' 30 | Out-Null
    $id = Invoke-Sql "SELECT id FROM files.catalog_items WHERE name='$name';"
    Assert-Qa03 (-not [string]::IsNullOrWhiteSpace($id)) 'Location manager item exists in real PostgreSQL.'
    $sentinel = Join-Path $runtimeRoot 'location-sentinel.txt'
    [IO.File]::WriteAllText($sentinel, 'Location metadata must never delete this file.')
    $sentinelHash = (Get-FileHash -LiteralPath $sentinel -Algorithm SHA256).Hash

    Invoke-Element (Wait-ElementById $window 'AddLocationButton' 30 -Enabled)
    Set-ElementValue (Wait-ElementById $window 'LocationPathTextBox' 30) $sentinel
    Invoke-Element (Wait-ElementById $window 'SaveLocationButton' 30 -Enabled)
    Assert-ListContains $window 'LocationsList' $sentinel 60 | Out-Null
    Assert-Qa03 ((Invoke-Sql "SELECT count(*) FROM files.file_locations WHERE catalog_item_id='$id';") -eq '1') 'First real WPF location POST persisted.'

    $state = Get-Content -LiteralPath $statePath -Raw | ConvertFrom-Json
    $tokens = Login-Api $state.AdminLogin
    $headers = @{ Authorization = "Bearer $($tokens.accessToken)"; 'Idempotency-Key' = [guid]::NewGuid().ToString('D') }
    $resource = Invoke-WebRequest -Method Post -Uri "$($state.BaseUrl)/api/v1/network-resources" -Headers $headers -ContentType 'application/json' `
        -Body (@{ name = 'QA-03 location resource'; rootUncPath = '\\qa03-server\docs' } | ConvertTo-Json -Compress) -SkipHttpErrorCheck
    Assert-Qa03 ($resource.StatusCode -eq 201) 'Existing network-resource API creates the synthetic allowed resource.'
    $resourceId = ($resource.Content | ConvertFrom-Json).id
    Invoke-Element (Wait-ElementById $window 'AddLocationButton' 30 -Enabled)
    $type = Wait-ElementById $window 'LocationTypeCombo' 30
    ([System.Windows.Automation.ExpandCollapsePattern]$type.GetCurrentPattern([System.Windows.Automation.ExpandCollapsePattern]::Pattern)).Expand()
    $uncChoice = Wait-ElementByNameContains $type 'Сетевое расположение' 30 'ListItem'
    ([System.Windows.Automation.SelectionItemPattern]$uncChoice.GetCurrentPattern([System.Windows.Automation.SelectionItemPattern]::Pattern)).Select()
    $path = '\\qa03-server\docs\second.txt'
    Set-ElementValue (Wait-ElementById $window 'LocationPathTextBox' 30) $path
    $combo = Wait-ElementById $window 'LocationNetworkResourceCombo' 30
    ([System.Windows.Automation.ExpandCollapsePattern]$combo.GetCurrentPattern([System.Windows.Automation.ExpandCollapsePattern]::Pattern)).Expand()
    $resourceChoice = Wait-ElementByNameContains $combo 'QA-03 location resource' 30 'ListItem'
    ([System.Windows.Automation.SelectionItemPattern]$resourceChoice.GetCurrentPattern([System.Windows.Automation.SelectionItemPattern]::Pattern)).Select()
    Invoke-Element (Wait-ElementById $window 'SaveLocationButton' 30 -Enabled)
    Assert-ListContains $window 'LocationsList' $path 60 | Out-Null
    Assert-Qa03 ((Invoke-Sql "SELECT count(*) FROM files.file_locations WHERE catalog_item_id='$id';") -eq '2') 'Second WPF mutation uses the refreshed parent version.'
    Assert-Qa03 ((Invoke-Sql "SELECT network_resource_id FROM files.file_locations WHERE catalog_item_id='$id' AND location_type='unc_path';") -eq $resourceId) 'UNC picker sends the permitted resource identifier.'

    # Find a location card by its path, then operate its own buttons.
    $list = Wait-ElementById $window 'LocationsList' 30
    $card = Wait-ElementByNameExact $list $path 30
    Invoke-Element (Wait-ElementById $card 'EditLocationButton' 30 -Enabled)
    $edited = '\\qa03-server\docs\edited.txt'
    Set-ElementValue (Wait-ElementById $window 'LocationPathTextBox' 30) $edited
    $enabledBox = Wait-ElementById $window 'LocationEnabledCheckBox' 30
    ([System.Windows.Automation.TogglePattern]$enabledBox.GetCurrentPattern([System.Windows.Automation.TogglePattern]::Pattern)).Toggle()
    Invoke-Element (Wait-ElementById $window 'SaveLocationButton' 30 -Enabled)
    Assert-ListContains $window 'LocationsList' $edited 60 | Out-Null
    Assert-Qa03 ((Invoke-Sql "SELECT raw_path FROM files.file_locations WHERE catalog_item_id='$id' AND location_type='unc_path';") -eq $edited) 'WPF PATCH updates the real path.'
    Assert-Qa03 ((Invoke-Sql "SELECT is_enabled FROM files.file_locations WHERE catalog_item_id='$id' AND location_type='unc_path';") -eq 'f') 'WPF editor disables the persisted location.'

    $card = Wait-ElementByNameExact $list $edited 30
    Invoke-Element (Wait-ElementById $card 'EditLocationButton' 30 -Enabled)
    $enabledBox = Wait-ElementById $window 'LocationEnabledCheckBox' 30
    ([System.Windows.Automation.TogglePattern]$enabledBox.GetCurrentPattern([System.Windows.Automation.TogglePattern]::Pattern)).Toggle()
    $draft = '\\qa03-server\docs\draft.txt'
    Set-ElementValue (Wait-ElementById $window 'LocationPathTextBox' 30) $draft
    $current = Invoke-WebRequest -Uri "$($state.BaseUrl)/api/v1/catalog-items/$id" -Headers @{ Authorization = "Bearer $($tokens.accessToken)" }
    $etag = ($current.Headers['ETag'] | Select-Object -First 1).ToString()
    $patchHeaders = @{ Authorization = "Bearer $($tokens.accessToken)"; 'If-Match' = $etag }
    $external = Invoke-WebRequest -Method Patch -Uri "$($state.BaseUrl)/api/v1/catalog-items/$id" -Headers $patchHeaders `
        -ContentType 'application/json' -Body '{"description":"Concurrent real API edit"}' -SkipHttpErrorCheck
    Assert-Qa03 ($external.StatusCode -eq 200) 'Concurrent real API edit changes the catalog aggregate version.'
    Invoke-Element (Wait-ElementById $window 'SaveLocationButton' 30 -Enabled)
    Wait-ElementByNameContains $window 'Данные изменены другим пользователем' 60 | Out-Null
    Assert-Qa03 ((Invoke-Sql "SELECT raw_path FROM files.file_locations WHERE catalog_item_id='$id' AND location_type='unc_path';") -eq $edited) 'Real HTTP 412 preserves the other saved state without automatic overwrite.'
    Assert-Qa03 (([System.Windows.Automation.ValuePattern](Wait-ElementById $window 'LocationPathTextBox' 30).GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern)).Current.Value -eq $draft) 'Conflict keeps the user draft.'
    Invoke-Element (Wait-ElementById $window 'SaveLocationButton' 30 -Enabled)
    Assert-ListContains $window 'LocationsList' $draft 60 | Out-Null
    Assert-Qa03 ((Invoke-Sql "SELECT is_enabled FROM files.file_locations WHERE catalog_item_id='$id' AND location_type='unc_path';") -eq 't') 'Explicit conflict retry re-enables the persisted location.'
    $card = Wait-ElementByNameExact $list $draft 30
    Invoke-Element (Wait-ElementById $card 'MakePrimaryLocationButton' 30 -Enabled)
    Wait-ElementByNameContains $window 'Расположение сохранено.' 60 | Out-Null
    Assert-Qa03 ((Invoke-Sql "SELECT count(*) FROM files.file_locations WHERE catalog_item_id='$id' AND is_primary;") -eq '1') 'Server preserves exactly one primary location.'
    Assert-Qa03 ((Invoke-Sql "SELECT raw_path FROM files.file_locations WHERE catalog_item_id='$id' AND is_primary;") -eq $draft) 'Primary action changes the real server state.'
    Capture-Window 'locations-multiple' $window

    Invoke-Phase 'StopApi'
    Invoke-Element (Wait-ElementById $window 'RefreshLocationsButton' 30 -Enabled)
    Wait-ElementByNameContains $window 'Последние подтверждённые расположения сохранены' 60 | Out-Null
    Assert-ListContains $window 'LocationsList' $draft 30 | Out-Null
    Assert-Qa03 (-not (Wait-ElementById $window 'AddLocationButton' 30).Current.IsEnabled) 'Server loss preserves confirmed rows and disables mutations.'
    Invoke-Phase 'StartApi'
    Invoke-Element (Wait-ElementById $window 'RefreshLocationsButton' 30 -Enabled)
    Wait-ElementById $window 'AddLocationButton' 60 -Enabled | Out-Null

    foreach ($removePath in @($sentinel, $draft)) {
        $list = Wait-ElementById $window 'LocationsList' 30
        $card = Wait-ElementByNameExact $list $removePath 30
        Invoke-Element (Wait-ElementById $card 'DeleteLocationButton' 30 -Enabled)
        Assert-Qa03 ((Invoke-Sql "SELECT count(*) FROM files.file_locations WHERE catalog_item_id='$id' AND raw_path='$removePath';") -eq '1') 'Delete confirmation precedes the real DELETE.'
        Invoke-Element (Wait-ElementById $window 'ConfirmDeleteLocationButton' 30 -Enabled)
        Wait-ElementByNameContains $window 'Расположение удалено.' 60 | Out-Null
        Assert-Qa03 ((Invoke-Sql "SELECT count(*) FROM files.file_locations WHERE catalog_item_id='$id' AND raw_path='$removePath';") -eq '0') 'Confirmed WPF DELETE removes only location metadata.'
    }
    Wait-ElementById $window 'LocationsEmpty' 30 | Out-Null
    Assert-Qa03 ((Get-FileHash -LiteralPath $sentinel -Algorithm SHA256).Hash -eq $sentinelHash) 'Physical file remains unchanged after deleting the final location.'
    Capture-Window 'locations-empty' $window
    [IO.File]::WriteAllText((Join-Path $evidenceRoot 'location-manager-ui.json'), (@{
        version = '1.0.0'; result = 'PASS'; catalogItemId = $id; physicalFileUnchanged = $true
        checks = @('real WPF selection', 'empty', 'local POST', 'UNC resource picker', 'second mutation version', 'PATCH', 'real 412 draft recovery', 'primary', 'offline cache', 'reconnect', 'confirmed DELETE', 'last location')
    } | ConvertTo-Json -Depth 5), [Text.UTF8Encoding]::new($false))
}

try {
    if (Test-Path -LiteralPath $runtimeRoot) {
        throw "QA-03 clean runtime already exists at $runtimeRoot. Remove it only via the Cleanup phase."
    }
    if (-not $SkipBuild) {
        $buildOutput = & dotnet build (Join-Path $repoRoot 'work\production\Task.sln') `
            --configuration Release --no-restore 2>&1
        $buildExit = $LASTEXITCODE
        [IO.File]::WriteAllLines($buildLog, ($buildOutput | ForEach-Object { $_.ToString() }), [Text.UTF8Encoding]::new($false))
        $buildOutput | ForEach-Object { Write-Host $_ }
        Assert-Qa03 ($buildExit -eq 0) 'Release solution build passed.'
    }

    $setupStarted = $true
    Invoke-Phase 'Setup'
    $state = Get-Content -LiteralPath $statePath -Raw | ConvertFrom-Json
    Assert-Qa03 ($state.AdminLogin -eq 'task-e2e-admin') 'QA-03 deterministic seed profile is active.'

    if ($LocationsOnly) {
        $oldTestConnection = $env:TASK_POSTGRES_TEST_ADMIN_CONNECTION
        try {
            $env:TASK_POSTGRES_TEST_ADMIN_CONNECTION = "Host=127.0.0.1;Port=$($state.PostgresPort);Database=postgres;Username=postgres;SSL Mode=Disable"
            & dotnet test (Join-Path $repoRoot 'work\production\Task.sln') --configuration Release --no-build --no-restore --logger trx --results-directory $evidenceRoot *> (Join-Path $evidenceRoot 'full-tests.log')
            Assert-Qa03 ($LASTEXITCODE -eq 0) 'All solution tests pass with real PostgreSQL enabled.'
        }
        finally { $env:TASK_POSTGRES_TEST_ADMIN_CONNECTION = $oldTestConnection }
        $window = Start-Desktop
        Test-LocationManager $window
        Write-Pass 'QA-03 LOCATION MANAGER E2E PASSED.'
        return
    }

    Invoke-Qa03Phase 'SeedProductData'
    Invoke-Qa03Phase 'VerifyProductApi'
    Invoke-Qa03Phase 'RunWorkerDelivery'
    $state = Get-Content -LiteralPath $statePath -Raw | ConvertFrom-Json

    $ui = [ordered]@{}
    $window = Start-Desktop
    $connection = (Wait-ElementById $window 'ConnectionStatusText').Current.Name
    Assert-Qa03 ($connection -match '^Подключено к серверу компании') 'Admin WPF is connected to the production HTTPS API.'

    $todayScreen = Wait-ElementById $window 'TodayScreen' 60
    Assert-Qa03 ((Wait-ElementByNameContains $todayScreen 'QA-03 today timed task' 60).Current.Name.Contains('QA-03 today timed task')) 'Today shows the seeded timed task.'
    Assert-Qa03 ((Wait-ElementByNameContains $todayScreen 'QA-03 today untimed task' 60).Current.Name.Contains('QA-03 today untimed task')) 'Today shows the seeded untimed task.'
    Assert-Qa03 ((Wait-ElementByNameContains $todayScreen 'QA-03 overdue task' 60).Current.Name.Contains('QA-03 overdue task')) 'Today shows the seeded overdue task.'
    Assert-Qa03 ((Wait-ElementByNameContains $todayScreen 'QA-03 deterministic event' 60).Current.Name.Contains('QA-03 deterministic event')) 'Today shows the seeded all-day event.'
    $ui['today'] = 'PASS'
    Resize-Window $window 1487 1058
    $window = Find-MainWindow
    Assert-Qa03 ($null -ne $window) 'Main WPF window remains available after normal sizing.'
    Capture-Window 'today-normal' $window
    Resize-Window $window 1200 900
    $window = Find-MainWindow
    Assert-Qa03 ($null -ne $window) 'Main WPF window remains available after compact sizing.'
    Dump-UiaTree $window (Join-Path $evidenceRoot 'today-compact-uia.txt')
    Capture-Window 'today-compact-1200x900' $window
    foreach ($id in @('TodayPlannerRegion', 'TodayQueueRegion', 'TodayInspectorRegion', 'TodayOpenSelectedButton')) {
        $element = Wait-ElementById $window $id 30
        Assert-Qa03 (-not $element.Current.IsOffscreen) "Today compact layout keeps $id visible."
    }
    $ui['todayCompact'] = 'PASS'

    Navigate-To $window 'inbox' 'InboxScreen'
    $inboxTitle = 'QA-03 входящая запись с длинной русской строкой'
    $captureBox = Wait-ElementById $window 'InboxCaptureTextBox' 30
    Set-ElementValue $captureBox $inboxTitle
    Invoke-Element (Wait-ElementById $window 'InboxCaptureButton' 30 -Enabled)
    $capturedInbox = Assert-ListContains $window 'InboxList' $inboxTitle 60
    Assert-Qa03 ($capturedInbox.Current.Name.Contains('Без классификации')) 'Quick capture created a real unclassified server task.'
    $ui['inboxCapture'] = 'PASS'
    Resize-Window $window 1280 900
    $window = Find-MainWindow
    Capture-Window 'inbox-direction2' $window

    $inboxSelection = [System.Windows.Automation.SelectionItemPattern]$capturedInbox.GetCurrentPattern(
        [System.Windows.Automation.SelectionItemPattern]::Pattern)
    $inboxSelection.Select()
    Invoke-Element (Wait-ElementById $window 'InboxConvertButton' 30 -Enabled)
    Wait-ElementById $window 'InboxConversionTitleBox' 30 | Out-Null
    Write-Pass 'Inbox conversion opens from the accessible split-layout inspector.'
    Start-Sleep -Milliseconds 750
    Capture-Window 'inbox-conversion-open' $window
    Dump-UiaTree $window (Join-Path $evidenceRoot 'inbox-conversion-uia.txt')
    $conversionDeadline = Wait-ElementById $window 'InboxConversionDeadline' 30
    Set-ElementValue $conversionDeadline ([DateTime]::Today.AddDays(14).AddHours(17).ToString('dd.MM.yyyy HH:mm'))
    Capture-Window 'inbox-conversion-direction2' $window
    Invoke-Element (Wait-ElementById $window 'InboxSaveConversionButton' 30 -Enabled)
    Wait-ElementGoneById $window 'InboxConversionTitleBox' 60
    Navigate-To $window 'tasks' 'TasksList'
    $convertedTask = Assert-TaskListItem $window $inboxTitle 60
    Assert-Qa03 ($convertedTask.Current.Name.Contains($inboxTitle)) 'Inbox conversion kept the same server task identity and title.'
    Assert-Qa03 (-not $convertedTask.Current.Name.Contains('Срок: Без срока')) 'Inbox conversion persisted the required deadline.'
    $ui['inboxConversion'] = 'PASS'
    Capture-Window 'tasks-direction2' $window

    Navigate-To $window 'tasks' 'NewTaskButton'
    Invoke-Element (Wait-ElementById $window 'NewTaskButton' 30 -Enabled)
    $title = Wait-ElementById $window 'TaskTitleTextBox'
    Set-ElementValue $title 'QA-03 ui created task'
    Invoke-Element (Wait-ElementById $window 'SaveTaskButton' 15 -Enabled)
    $createdItem = Assert-TaskListItem $window 'QA-03 ui created task'
    Assert-Qa03 ($createdItem.Current.Name -match 'Статус: Запланирована') 'Admin created a deterministic task through the real WPF UI.'
    $ui['taskCreate'] = 'PASS'
    Capture-Window 'tasks-created' $window

    $uiTaskId = Invoke-Sql "SELECT id FROM work.tasks WHERE title = 'QA-03 ui created task' LIMIT 1;"
    Assert-Qa03 (-not [string]::IsNullOrWhiteSpace($uiTaskId)) 'UI-created task row exists in PostgreSQL.'

    $inspector = Wait-ElementByNameExact $window 'Сведения о выбранной задаче' 30
    $expandPattern = [System.Windows.Automation.ExpandCollapsePattern]$inspector.GetCurrentPattern(
        [System.Windows.Automation.ExpandCollapsePattern]::Pattern)
    if ($expandPattern.Current.ExpandCollapseState -ne
        [System.Windows.Automation.ExpandCollapseState]::Expanded) {
        $expandPattern.Expand()
    }
    Invoke-Element (Wait-ElementById $window 'EditTaskButton' 30 -Enabled)
    $editorTitle = Wait-ElementById $window 'TaskTitleTextBox' 30
    Patch-TaskTitle $uiTaskId 'QA-03 ui task concurrent edit'
    Set-ElementValue $editorTitle 'QA-03 ui draft title'
    Invoke-Element (Wait-ElementById $window 'SaveTaskButton' 15 -Enabled)
    $reload = Wait-ElementById $window 'ReloadConflictButton' 30 -Enabled
    Assert-Qa03 ($null -ne $reload) 'Concurrent server edit surfaces the safe conflict UI.'
    $ui['taskConflict'] = 'PASS'
    Capture-Window 'tasks-conflict' $window
    Invoke-Element $reload
    $reloadedTitle = Wait-ElementById $window 'TaskTitleTextBox' 30
    Set-ElementValue $reloadedTitle 'QA-03 ui task final'
    Invoke-Element (Wait-ElementById $window 'SaveTaskButton' 30 -Enabled)
    $finalItem = Assert-TaskListItem $window 'QA-03 ui task final'
    Assert-Qa03 ($finalItem.Current.Name -match 'Статус: Запланирована') 'Conflict reload and explicit re-save completed the task edit.'
    $ui['taskConflictRecovery'] = 'PASS'
    Capture-Window 'tasks-recovered' $window

    Navigate-To $window 'calendar' 'CalendarScreen'
    $calendarScreen = Wait-ElementById $window 'CalendarScreen' 30
    $weekRange = (Wait-ElementById $calendarScreen 'CalendarWeekRange' 30).Current.Name
    Assert-Qa03 (-not [string]::IsNullOrWhiteSpace($weekRange)) 'Calendar shows the current week range.'
    Resize-Window $window 1487 1058
    $window = Find-MainWindow
    $calendarScreen = Wait-ElementById $window 'CalendarScreen' 30
    Dump-UiaTree $calendarScreen (Join-Path $evidenceRoot 'calendar-week-uia.txt')
    Capture-Window 'calendar-week' $window
    Assert-Qa03 ((Wait-ElementByNameContains $calendarScreen 'QA-03 deterministic event' 60).Current.Name.Contains('QA-03 deterministic event')) 'Calendar grid renders the seeded event.'
    Assert-Qa03 ((Wait-ElementByNameContains $calendarScreen 'QA-03 recurrence E2E' 60).Current.Name.Contains('QA-03 recurrence E2E')) 'Calendar grid renders the seeded recurrence occurrence.'
    $overlapA = Wait-ElementByNameContains $calendarScreen 'QA-03 overlap A' 60 'Button'
    $overlapB = Wait-ElementByNameContains $calendarScreen 'QA-03 overlap B' 60 'Button'
    Assert-Qa03 (-not $overlapA.Current.IsOffscreen -and -not $overlapB.Current.IsOffscreen) 'Overlapping calendar events remain visible as separate controls.'
    $ui['calendar'] = 'PASS'
    Invoke-Element $overlapA
    Start-Sleep -Milliseconds 750
    Dump-UiaTree $calendarScreen (Join-Path $evidenceRoot 'calendar-selected-uia.txt')
    Capture-Window 'calendar-overlap' $window
    $selectionInspector = Wait-ElementById $window 'CalendarSelectionInspector' 30
    Assert-Qa03 ((Wait-ElementByNameContains $selectionInspector 'QA-03 overlap A' 30).Current.Name.Contains('QA-03 overlap A')) 'Calendar selection inspector exposes the invoked event.'
    Invoke-Element (Wait-ElementById $window 'CalendarNewEvent' 30 -Enabled)
    Wait-ElementById $window 'CalendarEventEditor' 30 | Out-Null
    $calendarEventTitle = Wait-ElementById $window 'CalendarEventTitle' 30
    Set-ElementValue $calendarEventTitle 'QA-03 calendar UI event'
    Capture-Window 'calendar-editor' $window
    Invoke-Element (Wait-ElementById $window 'CalendarEventSave' 30 -Enabled)
    Wait-ElementGoneById $window 'CalendarEventEditor' 30
    $createdCalendarEvent = Wait-ElementByNameContains $calendarScreen 'QA-03 calendar UI event' 60 'Button'
    Assert-Qa03 ($createdCalendarEvent.Current.Name.Contains('QA-03 calendar UI event')) 'Calendar event creation persists through the real WPF editor.'
    Invoke-Element $createdCalendarEvent
    Invoke-Element (Wait-ElementById $window 'CalendarEditEvent' 30 -Enabled)
    Wait-ElementById $window 'CalendarEventEditor' 30 | Out-Null
    Set-ElementValue (Wait-ElementById $window 'CalendarEventTitle' 30) 'QA-03 calendar UI event updated'
    Invoke-Element (Wait-ElementById $window 'CalendarEventSave' 30 -Enabled)
    Wait-ElementGoneById $window 'CalendarEventEditor' 30
    Assert-Qa03 ((Wait-ElementByNameContains $calendarScreen 'QA-03 calendar UI event updated' 60 'Button').Current.Name.Contains('QA-03 calendar UI event updated')) 'Calendar event edit persists through the real WPF editor.'
    $ui['calendarDirection2'] = 'PASS'

    Navigate-To $window 'projects' 'ProjectsView'
    Wait-ElementById $window 'ProjectsView' 30 | Out-Null
    try {
        Assert-Qa03 ((Assert-ListContains $window 'ProjectsList' 'QA-03 deterministic project' 60).Current.Name.Contains('QA-03 deterministic project')) 'Projects list renders the seeded project.'
    }
    catch {
        Dump-UiaTree $window (Join-Path $evidenceRoot 'projects-failed-tree.txt')
        Capture-Window 'projects-failed' $window
        throw
    }
    Invoke-Element (Wait-ElementById $window 'NewProjectButton' 30 -Enabled)
    $projectName = Wait-ElementById $window 'ProjectNameTextBox' 30
    Set-ElementValue $projectName 'QA-03 ui created project'
    Invoke-Element (Wait-ElementById $window 'SaveProjectButton' 30 -Enabled)
    $uiProject = Assert-ListContains $window 'ProjectsList' 'QA-03 ui created project' 60
    Assert-Qa03 ($uiProject.Current.Name.Contains('QA-03 ui created project')) 'Project was created through the real WPF UI.'
    $ui['projectCreate'] = 'PASS'
    Capture-Window 'projects' $window

    Navigate-To $window 'catalog' 'WorkHubView'
    Wait-ElementById $window 'WorkHubView' 30 | Out-Null
    Assert-Qa03 ((Assert-ListContains $window 'CatalogList' 'QA-03 deterministic file.txt' 60).Current.Name.Contains('QA-03 deterministic file.txt')) 'Catalog list renders the seeded file reference.'
    $catalogNameBox = Wait-ElementByNameExact $window 'Название записи' 30
    Set-ElementValue $catalogNameBox 'QA-03 ui catalog file'
    Invoke-Element (Wait-ElementById $window 'CreateCatalogItemButton' 30 -Enabled)
    $uiCatalog = Assert-ListContains $window 'CatalogList' 'QA-03 ui catalog file' 60
    Assert-Qa03 ($uiCatalog.Current.Name.Contains('QA-03 ui catalog file')) 'Catalog entry was created through the real WPF UI.'
    $ui['catalogCreate'] = 'PASS'
    Capture-Window 'catalog' $window
    Test-LocationManager $window
    $ui['locationManager'] = 'PASS'

    Navigate-To $window 'contacts' 'WorkHubView'
    Wait-ElementById $window 'WorkHubView' 30 | Out-Null
    $firstName = Wait-ElementById $window 'ContactFirstNameTextBox' 30
    $displayName = Wait-ElementById $window 'ContactDisplayNameTextBox' 30
    Set-ElementValue $firstName 'Qa03Ui'
    Set-ElementValue $displayName 'QA-03 ui contact'
    Invoke-Element (Wait-ElementById $window 'CreateContactButton' 30 -Enabled)
    $uiContact = Assert-ListContains $window 'ContactsList' 'QA-03 ui contact' 60
    Assert-Qa03 ($uiContact.Current.Name.Contains('QA-03 ui contact')) 'Contact was created through the real WPF UI.'
    $ui['contactCreate'] = 'PASS'
    Capture-Window 'contacts' $window

    Navigate-To $window 'search' 'WorkHubView'
    Wait-ElementById $window 'WorkHubView' 30 | Out-Null
    $searchBox = Wait-ElementById $window 'GlobalSearchTextBox' 30
    Set-ElementValue $searchBox 'QA-03 deterministic project'
    Invoke-Element (Wait-ElementById $window 'GlobalSearchButton' 30 -Enabled)
    $searchHit = Assert-ListContains $window 'GlobalSearchResults' 'QA-03 deterministic project' 60
    Assert-Qa03 ($searchHit.Current.Name.Contains('QA-03 deterministic project')) 'Global search finds the seeded project in the real WPF UI.'
    $ui['search'] = 'PASS'
    Capture-Window 'search' $window

    Navigate-To $window 'notifications' 'WorkHubView'
    Wait-ElementById $window 'WorkHubView' 30 | Out-Null
    $notification = Assert-ListContains $window 'NotificationsList' 'Напоминание' 60
    Assert-Qa03 ($notification.Current.Name.Contains('Напоминание')) 'Notification center renders the worker-delivered reminder.'
    $deliveredState = Assert-ListContains $window 'NotificationsList' 'delivered' 30
    Assert-Qa03 ($deliveredState.Current.Name.Contains('delivered')) 'Notification center shows the unread delivered state.'
    # Read items are intentionally hidden by the default unread-only filter.
    $notificationFilter = Wait-ElementByNameExact $window 'Фильтр уведомлений' 30
    $filterExpansion = [System.Windows.Automation.ExpandCollapsePattern]$notificationFilter.GetCurrentPattern(
        [System.Windows.Automation.ExpandCollapsePattern]::Pattern)
    $filterExpansion.Expand()
    $allNotifications = Wait-ElementByNameExact $notificationFilter 'Все' 30
    ([System.Windows.Automation.SelectionItemPattern]$allNotifications.GetCurrentPattern(
        [System.Windows.Automation.SelectionItemPattern]::Pattern)).Select()
    $filterExpansion.Collapse()
    Invoke-Element (Wait-ElementById $window 'MarkAllNotificationsReadButton' 30 -Enabled)
    $readState = Assert-ListContains $window 'NotificationsList' 'read' 60
    Assert-Qa03 ($readState.Current.Name.Contains('read')) 'Mark-all-read transitioned the reminder to the read state.'
    $ui['notifications'] = 'PASS'
    Capture-Window 'notifications' $window

    Navigate-To $window 'tasks' 'NewTaskButton'
    Invoke-Phase 'StopApi'
    Invoke-Element (Wait-ElementById $window 'TasksRefreshButton' 30 -Enabled)
    Wait-StatusText $window 'Сервер недоступен' 60 | Out-Null
    $offlineNew = Wait-ElementById $window 'NewTaskButton' 30
    Assert-Qa03 (-not $offlineNew.Current.IsEnabled) 'Server loss disables task creation in the shell.'
    $offlineContext = (Wait-ElementById $window 'ConnectionStatusText' 30).Current.Name
    Assert-Qa03 ($offlineContext -match 'Сервер недоступен') 'Shell truthfully reports the offline state.'
    $ui['offlineShell'] = 'PASS'
    Navigate-To $window 'today' 'TodayScreen'
    $readOnlyBanner = Wait-ElementById $window 'TodayStateBanner' 30
    Assert-Qa03 ($readOnlyBanner.Current.Name -match 'Нет подключения') 'Today exposes the offline/read-only banner.'
    Assert-Qa03 (-not (Wait-ElementById $window 'TodayOpenSelectedButton' 30).Current.IsOffscreen) 'Cached Today selection remains inspectable offline.'
    Capture-Window 'today-offline-readonly' $window
    $ui['todayOfflineReadOnly'] = 'PASS'
    Navigate-To $window 'calendar' 'CalendarScreen'
    $calendarReadOnly = Wait-ElementById $window 'CalendarReadOnlyBanner' 30
    Assert-Qa03 (-not $calendarReadOnly.Current.IsOffscreen) 'Calendar exposes its offline read-only banner.'
    Assert-Qa03 (-not (Wait-ElementById $window 'CalendarNewEvent' 30).Current.IsEnabled) 'Calendar event creation stays disabled offline.'
    Assert-Qa03 ((Wait-ElementByNameContains $window 'QA-03 overlap A' 30).Current.Name.Contains('QA-03 overlap A')) 'Cached calendar data remains inspectable offline.'
    Capture-Window 'calendar-offline' $window
    $ui['calendarOfflineReadOnly'] = 'PASS'
    Navigate-To $window 'tasks' 'NewTaskButton'

    Invoke-Phase 'StartApi'
    Invoke-Element (Wait-ElementById $window 'TasksRefreshButton' 30 -Enabled)
    Wait-StatusText $window 'Подключено к серверу компании' 60 | Out-Null
    $onlineNew = Wait-ElementById $window 'NewTaskButton' 30
    Assert-Qa03 ($onlineNew.Current.IsEnabled) 'Explicit refresh restores task creation after reconnect.'
    $ui['reconnect'] = 'PASS'
    Capture-Window 'reconnected' $window
    Stop-Desktop

    Invoke-Phase 'StopApi'
    Invoke-Phase 'StartApi'
    Invoke-Qa03Phase 'VerifyCriticalProduct'
    Invoke-Qa03Phase 'VerifyNotificationsApi'

    $uiEvidence = [ordered]@{
        schemaVersion = 1
        scenario = 'QA-03 critical user scenario E2E'
        seedProfile = 'qa03-deterministic-v1'
        result = 'PASS'
        executable = 'work/production/src/Task.Desktop/bin/Release/net10.0-windows/Task.Desktop.exe'
        initialConnection = $connection
        uiChecks = $ui
        uiTaskId = $uiTaskId
        conflictServerTitle = 'QA-03 ui task concurrent edit'
        finalTitle = 'QA-03 ui task final'
        startedAtUtc = $startedAt.ToString('O')
        completedAtUtc = [DateTimeOffset]::UtcNow.ToString('O')
    }
    [IO.File]::WriteAllText((Join-Path $evidenceRoot 'ui-assertions.json'),
        (($uiEvidence | ConvertTo-Json -Depth 6) + "`n"), [Text.UTF8Encoding]::new($false))
    Append-Log @('QA-03 CRITICAL E2E GATE PASSED.') $runLog
    Write-Pass 'QA-03 CRITICAL E2E GATE PASSED.'
}
catch {
    Write-Host $_.ScriptStackTrace
    if ($null -ne $window) {
        try { Dump-UiaTree $window (Join-Path $evidenceRoot 'failure-uia.txt'); Capture-Window 'failure' $window } catch { }
    }
    throw
}
finally {
    Stop-Desktop
    if ($setupStarted -and (Test-Path -LiteralPath $statePath -PathType Leaf)) {
        try { Invoke-Phase 'Cleanup' }
        catch { Append-Log @("CLEANUP FAILED: $($_.Exception.Message)") $runLog; throw }
    }
}
